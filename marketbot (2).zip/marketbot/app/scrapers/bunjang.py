from .base import Item, Scraper, ScraperError
from ..util import to_int


class Bunjang(Scraper):
    key = "bunjang"
    label = "번개장터"

    async def search(self, client, query, region=""):
        r = await client.get(
            "https://api.bunjang.co.kr/api/1/find_v2.json",
            params={"q": query, "order": "date", "page": 0, "n": 100,
                    "stat_device": "w", "req_ref": "search", "version": 5},
        )
        if r.status_code != 200:
            raise ScraperError(f"HTTP {r.status_code}")
        try:
            data = r.json()
        except ValueError:
            raise ScraperError("JSON 응답이 아님 (차단 가능성)")
        if "list" not in data:
            raise ScraperError("응답 구조 변경: 'list' 없음")
        return parse(data)


def parse(data) -> list[Item]:
    items = []
    for it in data.get("list", []):
        pid = it.get("pid")
        if not pid or it.get("ad"):
            continue
        thumb = (it.get("product_image") or "").replace("{cnt}", "1").replace("{res}", "300")
        items.append(Item(
            site="bunjang", item_id=str(pid), title=(it.get("name") or "").strip(),
            url=f"https://m.bunjang.co.kr/products/{pid}",
            price=to_int(it.get("price")), location=it.get("location") or "",
            thumb=thumb, posted_at=to_int(it.get("update_time")),
        ))
    return items
