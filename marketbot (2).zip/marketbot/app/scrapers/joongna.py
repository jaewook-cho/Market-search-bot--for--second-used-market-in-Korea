from datetime import datetime
from urllib.parse import quote

from .base import Item, Scraper, ScraperError, extract_next_data, walk
from ..util import KST, to_int


class Joongna(Scraper):
    key = "joongna"
    label = "중고나라"

    async def search(self, client, query, region=""):
        r = await client.get(f"https://web.joongna.com/search/{quote(query)}",
                             params={"sort": "RECENT_SORT"})
        if r.status_code != 200:
            raise ScraperError(f"HTTP {r.status_code}")
        return parse(r.text)


def _ts(v):
    if not v:
        return None
    if isinstance(v, (int, float)):
        return int(v / 1000) if v > 1e11 else int(v)
    try:
        return int(datetime.fromisoformat(str(v)).replace(tzinfo=KST).timestamp())
    except ValueError:
        return None


def parse(html: str) -> list[Item]:
    data = extract_next_data(html)
    if data is None:
        raise ScraperError("__NEXT_DATA__ 없음: 페이지 구조 변경 또는 차단")
    found = walk(data, lambda d: "seq" in d and "title" in d and "price" in d)
    items, seen = [], set()
    for d in found:
        seq = str(d["seq"])
        if seq in seen:
            continue
        seen.add(seq)
        loc = d.get("locationNames") or d.get("location") or ""
        if isinstance(loc, list):
            loc = " ".join(map(str, loc))
        items.append(Item(
            site="joongna", item_id=seq, title=str(d.get("title") or "").strip(),
            url=f"https://web.joongna.com/product/{seq}",
            price=to_int(d.get("price")), location=str(loc),
            thumb=d.get("url") or d.get("imageUrl") or "",
            posted_at=_ts(d.get("sortDate") or d.get("regDate")),
        ))
    return items
