import re
from datetime import datetime

from bs4 import BeautifulSoup

from .base import Item, Scraper, ScraperError
from ..util import KST, parse_price

_ID = re.compile(r"/service/board/sold/(\d+)")


class Clien(Scraper):
    key = "clien"
    label = "클리앙 장터"

    async def search(self, client, query, region=""):
        r = await client.get("https://www.clien.net/service/board/sold",
                             params={"od": "T31", "category": 0, "po": 0, "sk": "title", "sv": query})
        if r.status_code != 200:
            raise ScraperError(f"HTTP {r.status_code}")
        return parse(r.text)


def parse(html: str) -> list[Item]:
    soup = BeautifulSoup(html, "html.parser")
    items, seen = [], set()
    for a in soup.find_all("a", href=_ID):
        pid = _ID.search(a["href"]).group(1)
        if pid in seen:
            continue
        span = a.find("span", class_="subject_fixed")
        title = (span.get("title") or span.get_text()) if span else a.get_text()
        title = " ".join(title.split())
        if not title:
            continue
        seen.add(pid)
        ts = None
        row = a.find_parent(class_="list_item")
        if row:
            t = row.find(class_="timestamp")
            if t:
                try:
                    ts = int(datetime.strptime(t.get_text(strip=True), "%Y-%m-%d %H:%M:%S")
                             .replace(tzinfo=KST).timestamp())
                except ValueError:
                    pass
        items.append(Item(site="clien", item_id=pid, title=title,
                          url=f"https://www.clien.net/service/board/sold/{pid}",
                          price=parse_price(title), posted_at=ts))
    if not items and "sold" not in html:
        raise ScraperError("클리앙 페이지 구조 변경 또는 차단")
    return items
