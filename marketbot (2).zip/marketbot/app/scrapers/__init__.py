from .bunjang import Bunjang
from .clien import Clien
from .daangn import Daangn
from .dvdprime import DVDPrime
from .joongna import Joongna

REGISTRY = {s.key: s for s in (Daangn(), Joongna(), Bunjang(), Clien(), DVDPrime())}
