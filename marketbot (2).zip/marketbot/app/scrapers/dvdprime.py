import re
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from .base import Item, Scraper, ScraperError, decode
from ..util import parse_price

BASE = "https://dvdprime.com/g2/bbs/"
_WR = re.compile(r"wr_id=(\d+)")


class DVDPrime(Scraper):
    key = "dvdprime"
    label = "DVD프라임"

    async def search(self, client, query, region=""):
        r = await client.get(BASE + "board.php",
                             params={"bo_table": "market", "sca": "", "sfl": "wr_subject", "stx": query})
        if r.status_code != 200:
            raise ScraperError(f"HTTP {r.status_code}")
        return parse(decode(r))


def parse(html: str) -> list[Item]:
    soup = BeautifulSoup(html, "html.parser")
    items, seen = [], set()
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if "bo_table=market" not in href or "#c_" in href:
            continue
        m = _WR.search(href)
        if not m or m.group(1) in seen:
            continue
        title = " ".join(a.get_text(" ", strip=True).split())
        if not title:
            continue
        seen.add(m.group(1))
        items.append(Item(
            site="dvdprime", item_id=m.group(1), title=title,
            url=f"{BASE}board.php?bo_table=market&wr_id={m.group(1)}",
            price=parse_price(title),
        ))
    if not items and "market" not in html:
        raise ScraperError("DVD프라임 페이지 구조 변경 또는 차단")
    return items
