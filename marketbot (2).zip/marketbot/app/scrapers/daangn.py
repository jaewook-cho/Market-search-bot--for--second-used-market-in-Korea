import re
from datetime import datetime

from bs4 import BeautifulSoup

from .base import (Item, Scraper, ScraperError, extract_assigned_json,
                   extract_next_data, walk)
from ..util import parse_price, to_int

BASE = "https://www.daangn.com"
_ART = re.compile(r"/buy-sell/([^/?#]+-[a-z0-9]{6,})/?")


class Daangn(Scraper):
    key = "daangn"
    label = "당근마켓"

    async def search(self, client, query, region=""):
        params = {"search": query, "only_on_sale": "true"}
        if region:
            params["in"] = region  # 예: 역삼동-6035
        r = await client.get(f"{BASE}/kr/buy-sell/", params=params)
        if r.status_code != 200:
            raise ScraperError(f"HTTP {r.status_code}")
        return parse(r.text)


def _ts(v):
    if not v:
        return None
    try:
        return int(datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp())
    except ValueError:
        return None


def _from_json(html):
    data = extract_assigned_json(html, "__remixContext") or extract_next_data(html)
    if data is None:
        return []
    found = walk(data, lambda d: "title" in d and isinstance(d.get("href"), str)
                 and "/buy-sell/" in d["href"])
    out, seen = [], set()
    for d in found:
        m = _ART.search(d["href"])
        if not m or m.group(1) in seen:
            continue
        if str(d.get("status", "")).lower() in ("closed", "completed", "hided"):
            continue
        seen.add(m.group(1))
        reg = d.get("region") or d.get("regionName") or ""
        if isinstance(reg, dict):
            reg = reg.get("name") or reg.get("name3") or ""
        thumb = d.get("thumbnail") or ""
        out.append(Item(
            site="daangn", item_id=m.group(1), title=str(d["title"]).strip(),
            url=f"{BASE}/kr/buy-sell/{m.group(1)}/", price=to_int(d.get("price")),
            location=str(reg), thumb=thumb if isinstance(thumb, str) else "",
            posted_at=_ts(d.get("boostedAt") or d.get("createdAt")),
        ))
    return out


def _from_html(html):
    soup = BeautifulSoup(html, "html.parser")
    out, seen = [], set()
    for a in soup.find_all("a", href=True):
        m = _ART.search(a["href"])
        if not m or m.group(1) in seen:
            continue
        texts = [t for t in a.stripped_strings if t]
        if not texts:
            continue
        price, title, loc = None, None, ""
        for t in texts:
            if price is None and ("원" in t or t == "나눔") and re.search(r"[\d,]+원|나눔", t):
                price = 0 if "나눔" in t else parse_price(t)
            elif title is None:
                title = t
            elif not loc and ("동" in t or "구" in t or "·" in t):
                loc = t
        if not title:
            continue
        seen.add(m.group(1))
        img = a.find("img")
        out.append(Item(
            site="daangn", item_id=m.group(1), title=title,
            url=f"{BASE}/kr/buy-sell/{m.group(1)}/", price=price, location=loc,
            thumb=(img.get("src") if img else "") or "",
        ))
    return out


def parse(html: str) -> list[Item]:
    items = _from_json(html) or _from_html(html)
    if not items and "buy-sell" not in html:
        raise ScraperError("당근 페이지 구조 변경 또는 차단 (매물 링크 없음)")
    return items
