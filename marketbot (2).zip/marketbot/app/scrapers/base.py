import json
import re
from dataclasses import dataclass


@dataclass
class Item:
    site: str
    item_id: str
    title: str
    url: str
    price: int | None = None
    location: str = ""
    thumb: str = ""
    posted_at: int | None = None


class ScraperError(Exception):
    pass


class Scraper:
    key = ""
    label = ""

    async def search(self, client, query: str, region: str = "") -> list[Item]:
        raise NotImplementedError


def decode(resp) -> str:
    """인코딩이 깨졌으면(EUC-KR 사이트) 재디코딩."""
    text = resp.text
    if text.count("�") > 5:
        for enc in ("euc-kr", "cp949"):
            try:
                return resp.content.decode(enc, errors="replace")
            except LookupError:
                pass
    return text


def walk(obj, pred):
    """JSON 트리를 순회하며 pred(dict) 가 참인 dict 를 모두 반환 (구조 변경에 강하게)."""
    out, stack, seen = [], [obj], set()
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            if id(cur) in seen:
                continue
            seen.add(id(cur))
            if pred(cur):
                out.append(cur)
            stack.extend(cur.values())
        elif isinstance(cur, list):
            stack.extend(cur)
    return out


_NEXT_RE = re.compile(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', re.S)


def extract_next_data(html: str):
    m = _NEXT_RE.search(html)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except ValueError:
        return None


def extract_assigned_json(html: str, marker: str):
    """`window.__remixContext = {...};` 형태의 JSON 추출."""
    i = html.find(marker)
    if i < 0:
        return None
    j = html.find("{", i)
    if j < 0:
        return None
    try:
        obj, _ = json.JSONDecoder().raw_decode(html[j:])
        return obj
    except ValueError:
        return None
