import asyncio
import html

from .util import redact, register_secret

SITE_LABEL = {"daangn": "당근마켓", "joongna": "중고나라", "bunjang": "번개장터",
              "clien": "클리앙 장터", "dvdprime": "DVD프라임"}


class Telegram:
    def __init__(self, db, client):
        self.db, self.client = db, client
        register_secret(self.db.get_settings().get("tg_token"))

    def creds(self):
        s = self.db.get_settings()
        return (s.get("tg_token") or "").strip(), str(s.get("tg_chat_id") or "").strip()

    @property
    def configured(self) -> bool:
        t, c = self.creds()
        return bool(t and c)

    async def call(self, method, payload=None, token=None):
        token = token or self.creds()[0]
        if not token:
            return False, "봇 토큰이 설정되지 않았습니다"
        url = f"https://api.telegram.org/bot{token}/{method}"
        try:
            for attempt in range(2):
                r = await self.client.post(url, json=payload or {}, timeout=15)
                try:
                    data = r.json()
                except ValueError:
                    return False, f"HTTP {r.status_code}"
                if data.get("ok"):
                    return True, data.get("result")
                retry = (data.get("parameters") or {}).get("retry_after")
                if r.status_code == 429 and retry and attempt == 0:
                    await asyncio.sleep(min(int(retry), 30))
                    continue
                return False, redact(data.get("description") or f"HTTP {r.status_code}")
        except Exception as e:  # 네트워크 오류 — 메시지에 URL(토큰)이 들어갈 수 있어 마스킹
            return False, redact(f"{type(e).__name__}: {e}")
        return False, "알 수 없는 오류"

    async def send(self, text):
        _, chat = self.creds()
        if not chat:
            return False, "Chat ID가 설정되지 않았습니다"
        return await self.call("sendMessage", {"chat_id": chat, "text": text, "parse_mode": "HTML"})

    async def verify(self, token=None, chat_id=None):
        """연결 테스트: 토큰 유효성(getMe) + 채팅 접근(getChat)."""
        token = token or self.creds()[0]
        chat = chat_id or self.creds()[1]
        ok, me = await self.call("getMe", token=token)
        if not ok:
            return {"ok": False, "error": f"봇 토큰 오류: {me}"}
        res = {"ok": True, "bot": "@" + (me.get("username") or "?")}
        if chat:
            ok, c = await self.call("getChat", {"chat_id": chat}, token=token)
            if not ok:
                return {"ok": False, "bot": res["bot"],
                        "error": f"Chat ID 오류: {c} (봇에게 먼저 /start 를 보내세요)"}
            res["chat"] = c.get("title") or c.get("username") or c.get("first_name") or str(chat)
        else:
            res["ok"], res["error"] = False, "Chat ID가 비어 있습니다"
        return res


def fmt_item(it: dict) -> str:
    e = html.escape
    lines = [f"🆕 <b>[{e(SITE_LABEL.get(it['site'], it['site']))}]</b> · 검색어 {e(it.get('keyword') or '')}",
             f"<a href=\"{e(it['url'], quote=True)}\">{e(it['title'])}</a>"]
    meta = []
    p = it.get("price")
    meta.append("💰 " + ("나눔/무료" if p == 0 else f"{p:,}원") if p is not None else "💰 가격 미표기")
    if it.get("location"):
        meta.append("📍 " + e(it["location"]))
    lines.append(" · ".join(meta))
    return "\n".join(lines)
