"""검색 엔진: 필터링, 중복 방지, 주기 실행, 알림 전송."""
import asyncio
import logging
import time
from dataclasses import asdict

import httpx

from .notifier import Telegram, fmt_item
from .scrapers import REGISTRY
from .util import redact

log = logging.getLogger("marketbot.engine")

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/124.0.0.0 Safari/537.36")
PENDING_WINDOW = 6 * 3600       # 알림 실패분은 6시간 안에서만 재시도
FAIL_ALERT_AT = 3               # 같은 사이트 연속 N회 실패 시 텔레그램 경고(1회)


def words(s: str) -> list[str]:
    return [w.lower() for w in (s or "").replace(",", " ").split() if w.strip()]


def passes(item, query, mn, mx, exclude, strict) -> bool:
    t = item.title.lower()
    flat = t.replace(" ", "")
    if strict and not all(tok in t or tok in flat for tok in query.lower().split()):
        return False
    if any(w in t or w in flat for w in exclude):
        return False
    if item.price is not None:      # 가격 미표기 글(클리앙/DVD프라임 등)은 가격 필터에서 제외하지 않음
        if mn is not None and item.price < mn:
            return False
        if mx is not None and item.price > mx:
            return False
    return True


class Engine:
    def __init__(self, db):
        self.db = db
        self.client = httpx.AsyncClient(
            headers={"User-Agent": UA, "Accept-Language": "ko-KR,ko;q=0.9",
                     "Accept": "text/html,application/json,*/*"},
            follow_redirects=True, timeout=httpx.Timeout(20.0))
        self.tg = Telegram(db, self.client)
        self.lock = asyncio.Lock()
        self.running = False
        self.last_run = None
        self.next_run = time.time() + 15
        self.last_summary = ""

    # ------------------------------------------------------------ 스케줄
    def reschedule(self):
        s = self.db.get_settings()
        base = self.last_run or time.time()
        self.next_run = max(base + int(s["interval_min"]) * 60, time.time() + 5)

    async def loop(self):
        while True:
            try:
                s = self.db.get_settings()
                if s["auto_enabled"] and not self.running and time.time() >= self.next_run:
                    await self.run_cycle("auto")
            except Exception as e:
                log.error("스케줄 루프 오류: %s", redact(e))
            await asyncio.sleep(5)

    async def close(self):
        await self.client.aclose()

    # ------------------------------------------------------------ 사이트 호출
    async def fetch_site(self, site, query, region):
        last = None
        for attempt in range(2):
            try:
                return await REGISTRY[site].search(self.client, query, region)
            except Exception as e:
                last = e
                await asyncio.sleep(1.5)
        raise last

    @staticmethod
    def errmsg(e):
        return redact(f"{type(e).__name__}: {e}")[:200]

    # ------------------------------------------------------------ 수동 검색 (저장/알림 없음)
    async def adhoc(self, query, sites, mn, mx, exclude, region, sort):
        s = self.db.get_settings()
        sites = [x for x in (sites or list(REGISTRY)) if x in REGISTRY]
        ex = words(exclude) + words(s["global_exclude"])
        region = region or s["default_region"]
        res = await asyncio.gather(*[self.fetch_site(x, query, region) for x in sites],
                                   return_exceptions=True)
        out, status = [], {}
        for site, r in zip(sites, res):
            if isinstance(r, Exception):
                status[site] = {"ok": False, "message": self.errmsg(r), "count": 0}
                continue
            kept = [i for i in r if passes(i, query, mn, mx, ex, s["strict_title"])]
            status[site] = {"ok": True, "message": "", "count": len(kept)}
            out.extend(asdict(i) for i in kept)
        order = {id(x): n for n, x in enumerate(out)}
        if sort == "price":
            out.sort(key=lambda x: (x["price"] is None, x["price"] or 0))
        elif sort == "price_desc":
            out.sort(key=lambda x: (x["price"] is None, -(x["price"] or 0)))
        else:  # latest
            out.sort(key=lambda x: (x["posted_at"] is None, -(x["posted_at"] or 0), order[id(x)]))
        return {"items": out, "status": status}

    # ------------------------------------------------------------ 감시 실행
    async def run_cycle(self, trigger="auto", sites=None, keyword_ids=None):
        if self.lock.locked():
            return {"skipped": True}
        async with self.lock:
            self.running = True
            started = time.time()
            new_total = 0
            try:
                s = self.db.get_settings()
                enabled = [k for k, v in s["sites_enabled"].items() if v and k in REGISTRY]
                if sites:
                    enabled = [x for x in enabled if x in sites]
                kws = self.db.query("SELECT * FROM keywords WHERE enabled=1")
                if keyword_ids:
                    kws = [k for k in kws if k["id"] in keyword_ids]
                agg = {x: {"ok": 0, "err": [], "n": 0} for x in enabled} if kws else {}
                for kw in kws:
                    ksites = [x for x in enabled if not kw["sites"] or x in kw["sites"].split(",")]
                    region = kw["region"] or s["default_region"]
                    ex = words(kw["exclude"]) + words(s["global_exclude"])
                    res = await asyncio.gather(
                        *[self.fetch_site(x, kw["query"], region) for x in ksites],
                        return_exceptions=True)
                    for site, r in zip(ksites, res):
                        if isinstance(r, Exception):
                            agg[site]["err"].append(f"'{kw['query']}': {self.errmsg(r)}")
                            continue
                        agg[site]["ok"] += 1
                        new_total += self._store(kw, site, r, ex, s)
                    await asyncio.sleep(1.0)
                self._update_status(agg)
                await self._notify(s)
                for site, a in agg.items():
                    await self._maybe_alert(site, a)
            finally:
                self.running = False
                self.last_run = time.time()
                self.reschedule()
                self.last_summary = f"{trigger}: 신규 {new_total}건, {time.time() - started:.1f}초"
                log.info("검색 완료 (%s)", self.last_summary)
            return {"skipped": False, "new": new_total}

    def _store(self, kw, site, items, exclude, s) -> int:
        kept = [i for i in items if passes(i, kw["query"], kw["min_price"], kw["max_price"],
                                           exclude, s["strict_title"])]
        baselined = self.db.one("SELECT 1 x FROM baselines WHERE keyword_id=? AND site=?",
                                (kw["id"], site)) is not None
        now, new = int(time.time()), 0
        for i in kept:
            cur = self.db.execute(
                "INSERT OR IGNORE INTO items(site,item_id,title,price,url,location,thumb,posted_at,"
                "keyword_id,keyword,first_seen,notified) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (i.site, i.item_id, i.title, i.price, i.url, i.location, i.thumb, i.posted_at,
                 kw["id"], kw["query"], now, 0 if baselined else 1))
            new += cur.rowcount
        if not baselined:  # 첫 수집분은 기록만 하고 알리지 않음 (알림 폭탄 방지)
            self.db.execute("INSERT OR IGNORE INTO baselines VALUES(?,?)", (kw["id"], site))
        return new if baselined else 0

    def _update_status(self, agg):
        now = int(time.time())
        for site, a in agg.items():
            ok = a["ok"] > 0 or not a["err"]
            msg = " | ".join(a["err"])[:300]
            prev = self.db.one("SELECT fails FROM site_status WHERE site=?", (site,)) or {"fails": 0}
            fails = 0 if ok and not a["err"] else prev["fails"] + 1
            self.db.execute(
                "INSERT INTO site_status(site,last_run,ok,message,count,last_success,fails) "
                "VALUES(?,?,?,?,?,?,?) ON CONFLICT(site) DO UPDATE SET last_run=excluded.last_run,"
                "ok=excluded.ok,message=excluded.message,count=excluded.count,fails=excluded.fails,"
                "last_success=COALESCE(excluded.last_success, last_success)",
                (site, now, int(ok and not a["err"]), msg, a["ok"], now if a["ok"] else None, fails))

    async def _maybe_alert(self, site, a):
        row = self.db.one("SELECT fails FROM site_status WHERE site=?", (site,))
        if row and row["fails"] == FAIL_ALERT_AT and self.tg.configured:
            from .notifier import SITE_LABEL
            await self.tg.send(f"⚠️ <b>{SITE_LABEL[site]}</b> 검색이 {FAIL_ALERT_AT}회 연속 실패했습니다.\n"
                               "웹 관리 화면의 대시보드에서 오류를 확인하세요.")

    async def _notify(self, s):
        if not self.tg.configured:
            return
        pend = self.db.query("SELECT * FROM items WHERE notified=0 AND first_seen>=? ORDER BY first_seen, id",
                             (int(time.time()) - PENDING_WINDOW,))
        cap = int(s.get("notify_max_per_cycle") or 15)
        for it in pend[:cap]:
            ok, err = await self.tg.send(fmt_item(it))
            if not ok:
                log.warning("텔레그램 전송 실패: %s", err)
                return  # 다음 주기에 재시도
            self.db.execute("UPDATE items SET notified=1 WHERE id=?", (it["id"],))
            await asyncio.sleep(0.6)
        rest = pend[cap:]
        if rest:
            ok, _ = await self.tg.send(f"📦 신규 매물 {len(rest)}건이 더 있습니다. 웹 관리 화면의 '매물 기록'에서 확인하세요.")
            if ok:
                self.db.execute("UPDATE items SET notified=1 WHERE notified=0")
