"""SQLite 영구 저장소 (/data 볼륨). 설정·키워드·매물 기록·사이트 상태."""
import json
import os
import sqlite3
import threading

DATA_DIR = os.environ.get("DATA_DIR", "/data")

SITES = ["daangn", "joongna", "bunjang", "clien", "dvdprime"]

DEFAULT_SETTINGS = {
    "auto_enabled": True,
    "interval_min": 20,
    "sites_enabled": {s: True for s in SITES},
    "default_region": "",       # 당근 지역 (예: 역삼동-6035)
    "global_exclude": "",       # 전체 키워드 공통 제외어 (쉼표/공백 구분)
    "strict_title": True,       # 제목에 검색어가 실제로 포함된 글만
    "tg_token": "",
    "tg_chat_id": "",
    "notify_max_per_cycle": 15,
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS keywords (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  query TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  min_price INTEGER, max_price INTEGER,
  exclude TEXT NOT NULL DEFAULT '',
  region TEXT NOT NULL DEFAULT '',
  sites TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  site TEXT NOT NULL, item_id TEXT NOT NULL,
  title TEXT NOT NULL, price INTEGER, url TEXT NOT NULL,
  location TEXT DEFAULT '', thumb TEXT DEFAULT '',
  posted_at INTEGER, keyword_id INTEGER, keyword TEXT DEFAULT '',
  first_seen INTEGER NOT NULL, notified INTEGER NOT NULL DEFAULT 0,
  UNIQUE(site, item_id)
);
CREATE INDEX IF NOT EXISTS idx_items_seen ON items(first_seen DESC);
CREATE TABLE IF NOT EXISTS baselines (
  keyword_id INTEGER NOT NULL, site TEXT NOT NULL,
  PRIMARY KEY (keyword_id, site)
);
CREATE TABLE IF NOT EXISTS site_status (
  site TEXT PRIMARY KEY, last_run INTEGER, ok INTEGER, message TEXT DEFAULT '',
  count INTEGER DEFAULT 0, last_success INTEGER, fails INTEGER DEFAULT 0
);
"""


class DB:
    def __init__(self, path: str | None = None):
        os.makedirs(DATA_DIR, exist_ok=True)
        self.path = path or os.path.join(DATA_DIR, "marketbot.db")
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.lock = threading.RLock()
        with self.lock:
            self.conn.executescript(SCHEMA)
            self.conn.commit()
        try:
            os.chmod(self.path, 0o600)  # 토큰이 들어 있으므로 소유자만 읽기
        except OSError:
            pass

    def execute(self, sql, params=()):
        with self.lock:
            cur = self.conn.execute(sql, params)
            self.conn.commit()
            return cur

    def query(self, sql, params=()):
        with self.lock:
            return [dict(r) for r in self.conn.execute(sql, params).fetchall()]

    def one(self, sql, params=()):
        rows = self.query(sql, params)
        return rows[0] if rows else None

    # ---- settings
    def get_settings(self) -> dict:
        s = json.loads(json.dumps(DEFAULT_SETTINGS))
        for r in self.query("SELECT key, value FROM settings"):
            try:
                s[r["key"]] = json.loads(r["value"])
            except ValueError:
                pass
        s["sites_enabled"] = {**DEFAULT_SETTINGS["sites_enabled"], **(s.get("sites_enabled") or {})}
        return s

    def set_settings(self, updates: dict):
        with self.lock:
            for k, v in updates.items():
                self.conn.execute(
                    "INSERT INTO settings(key,value) VALUES(?,?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (k, json.dumps(v, ensure_ascii=False)),
                )
            self.conn.commit()
