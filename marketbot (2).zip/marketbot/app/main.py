import asyncio
import base64
import logging
import os
import secrets
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from pydantic import BaseModel

from .db import DB, SITES
from .engine import Engine
from .scrapers import REGISTRY
from .util import register_secret, setup_logging

setup_logging()
log = logging.getLogger("marketbot")

ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASS = os.environ.get("ADMIN_PASS", "")
STATIC = Path(__file__).parent / "static"

db: DB
engine: Engine


@asynccontextmanager
async def lifespan(app):
    global db, engine
    db = DB()
    engine = Engine(db)
    if not ADMIN_PASS:
        log.warning("ADMIN_PASS 가 비어 있어 관리 화면이 인증 없이 열려 있습니다!")
    task = asyncio.create_task(engine.loop())
    log.info("marketbot 시작 (data=%s)", db.path)
    yield
    task.cancel()
    await engine.close()


app = FastAPI(title="marketbot", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)


@app.middleware("http")
async def basic_auth(request: Request, call_next):
    if ADMIN_PASS and request.url.path != "/healthz":
        ok = False
        h = request.headers.get("authorization", "")
        if h.startswith("Basic "):
            try:
                u, _, p = base64.b64decode(h[6:]).decode("utf-8").partition(":")
                ok = secrets.compare_digest(u, ADMIN_USER) & secrets.compare_digest(p, ADMIN_PASS)
            except Exception:
                ok = False
        if not ok:
            return Response(status_code=401, headers={"WWW-Authenticate": 'Basic realm="marketbot"'})
    return await call_next(request)


# ---------------------------------------------------------------- 모델
class KeywordIn(BaseModel):
    query: str
    enabled: bool = True
    min_price: int | None = None
    max_price: int | None = None
    exclude: str = ""
    region: str = ""
    sites: list[str] = []


class SettingsIn(BaseModel):
    auto_enabled: bool | None = None
    interval_min: int | None = None
    sites_enabled: dict[str, bool] | None = None
    default_region: str | None = None
    global_exclude: str | None = None
    strict_title: bool | None = None
    tg_token: str | None = None
    tg_chat_id: str | None = None
    notify_max_per_cycle: int | None = None


class SearchIn(BaseModel):
    query: str
    sites: list[str] = []
    min_price: int | None = None
    max_price: int | None = None
    exclude: str = ""
    region: str = ""
    sort: str = "latest"


class RunIn(BaseModel):
    sites: list[str] = []
    keyword_ids: list[int] = []


def mask(tok: str) -> str:
    if not tok:
        return ""
    return tok[:3] + "•" * 12 + tok[-4:] if len(tok) > 10 else "•" * len(tok)


def public_settings():
    s = db.get_settings()
    tok = s.pop("tg_token", "")
    s["tg_token_masked"], s["tg_token_set"] = mask(tok), bool(tok)
    return s


def kw_row(r):
    r["enabled"] = bool(r["enabled"])
    r["sites"] = [x for x in (r["sites"] or "").split(",") if x]
    return r


def clean_sites(sites):
    return ",".join(x for x in sites if x in SITES)


# ---------------------------------------------------------------- 라우트
@app.get("/healthz")
def healthz():
    return {"ok": True}


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-store"})


@app.get("/api/meta")
def meta():
    return {"sites": [{"key": k, "label": v.label} for k, v in REGISTRY.items()]}


@app.get("/api/dashboard")
def dashboard():
    s = db.get_settings()
    st = {r["site"]: r for r in db.query("SELECT * FROM site_status")}
    day = int(time.time()) - 86400
    return {
        "now": int(time.time()), "running": engine.running,
        "last_run": engine.last_run, "next_run": engine.next_run if s["auto_enabled"] else None,
        "auto_enabled": s["auto_enabled"], "interval_min": s["interval_min"],
        "last_summary": engine.last_summary,
        "telegram_configured": engine.tg.configured,
        "keywords": db.one("SELECT COUNT(*) n, SUM(enabled) e FROM keywords"),
        "items_total": db.one("SELECT COUNT(*) n FROM items")["n"],
        "items_24h": db.one("SELECT COUNT(*) n FROM items WHERE first_seen>=?", (day,))["n"],
        "sites": [{"key": k, "label": v.label, "enabled": s["sites_enabled"].get(k, True),
                   "status": st.get(k)} for k, v in REGISTRY.items()],
    }


@app.get("/api/settings")
def get_settings():
    return public_settings()


@app.put("/api/settings")
async def put_settings(body: SettingsIn):
    upd = {k: v for k, v in body.model_dump().items() if v is not None}
    if "interval_min" in upd:
        upd["interval_min"] = max(1, min(int(upd["interval_min"]), 1440))
    if "notify_max_per_cycle" in upd:
        upd["notify_max_per_cycle"] = max(1, min(int(upd["notify_max_per_cycle"]), 50))
    if "tg_token" in upd:
        tok = upd["tg_token"].strip()
        if not tok or "•" in tok:      # 비었거나 마스킹된 값이면 기존 토큰 유지
            del upd["tg_token"]
        else:
            upd["tg_token"] = tok
            register_secret(tok)
    if "tg_chat_id" in upd:
        upd["tg_chat_id"] = upd["tg_chat_id"].strip()
    if "sites_enabled" in upd:
        upd["sites_enabled"] = {**db.get_settings()["sites_enabled"], **upd["sites_enabled"]}
    db.set_settings(upd)
    engine.reschedule()
    result = None
    if any(k in upd for k in ("tg_token", "tg_chat_id")):   # 저장 후 연결 테스트
        result = await engine.tg.verify()
    return {"settings": public_settings(), "telegram_test": result}


@app.post("/api/telegram/test")
async def telegram_test():
    v = await engine.tg.verify()
    if not v["ok"]:
        return v
    ok, err = await engine.tg.send("✅ marketbot 테스트 알림입니다. 연결이 정상입니다.")
    return {**v, "ok": ok, "error": None if ok else f"전송 실패: {err}"}


@app.get("/api/keywords")
def list_keywords():
    return [kw_row(r) for r in db.query("SELECT * FROM keywords ORDER BY id")]


@app.post("/api/keywords")
def add_keyword(k: KeywordIn):
    q = k.query.strip()
    if not q:
        raise HTTPException(400, "검색어를 입력하세요")
    cur = db.execute(
        "INSERT INTO keywords(query,enabled,min_price,max_price,exclude,region,sites,created_at) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (q, int(k.enabled), k.min_price, k.max_price, k.exclude.strip(), k.region.strip(),
         clean_sites(k.sites), int(time.time())))
    return kw_row(db.one("SELECT * FROM keywords WHERE id=?", (cur.lastrowid,)))


@app.put("/api/keywords/{kid}")
def edit_keyword(kid: int, k: KeywordIn):
    old = db.one("SELECT * FROM keywords WHERE id=?", (kid,))
    if not old:
        raise HTTPException(404)
    q = k.query.strip()
    if not q:
        raise HTTPException(400, "검색어를 입력하세요")
    db.execute("UPDATE keywords SET query=?,enabled=?,min_price=?,max_price=?,exclude=?,region=?,sites=? WHERE id=?",
               (q, int(k.enabled), k.min_price, k.max_price, k.exclude.strip(), k.region.strip(),
                clean_sites(k.sites), kid))
    if q != old["query"] or k.region.strip() != old["region"]:
        db.execute("DELETE FROM baselines WHERE keyword_id=?", (kid,))  # 새 기준으로 다시 베이스라인
    return kw_row(db.one("SELECT * FROM keywords WHERE id=?", (kid,)))


@app.delete("/api/keywords/{kid}")
def del_keyword(kid: int):
    db.execute("DELETE FROM keywords WHERE id=?", (kid,))
    db.execute("DELETE FROM baselines WHERE keyword_id=?", (kid,))
    return {"ok": True}


@app.post("/api/search")
async def manual_search(b: SearchIn):
    if not b.query.strip():
        raise HTTPException(400, "검색어를 입력하세요")
    return await engine.adhoc(b.query.strip(), b.sites, b.min_price, b.max_price,
                              b.exclude, b.region.strip(), b.sort)


@app.post("/api/run")
async def run_now(b: RunIn):
    if engine.running:
        return JSONResponse({"error": "이미 검색 중입니다"}, status_code=409)
    asyncio.create_task(engine.run_cycle("manual", b.sites or None, b.keyword_ids or None))
    return {"started": True}


@app.get("/api/items")
def items(site: str = "", q: str = "", sort: str = "new", limit: int = 50, offset: int = 0):
    where, p = [], []
    if site:
        where.append("site=?"); p.append(site)
    if q:
        where.append("(title LIKE ? OR keyword LIKE ?)"); p += [f"%{q}%", f"%{q}%"]
    w = ("WHERE " + " AND ".join(where)) if where else ""
    order = {"new": "first_seen DESC, id DESC", "price": "price IS NULL, price ASC",
             "price_desc": "price IS NULL, price DESC"}.get(sort, "first_seen DESC")
    total = db.one(f"SELECT COUNT(*) n FROM items {w}", p)["n"]
    rows = db.query(f"SELECT * FROM items {w} ORDER BY {order} LIMIT ? OFFSET ?",
                    p + [max(1, min(limit, 200)), max(0, offset)])
    return {"total": total, "items": rows}


@app.delete("/api/items")
def clear_items():
    db.execute("DELETE FROM items")
    db.execute("DELETE FROM baselines")   # 다음 검색은 다시 베이스라인(알림 없음)으로 시작
    return {"ok": True}
