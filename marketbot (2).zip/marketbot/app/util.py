"""공용 유틸: 가격 파싱, 로그/에러 메시지 비밀값 마스킹."""
import logging
import re
from zoneinfo import ZoneInfo

KST = ZoneInfo("Asia/Seoul")

# ---------------------------------------------------------------- 가격 파싱
_MAN = re.compile(r"(\d+(?:\.\d+)?)\s*만\s*(?:(\d+)\s*천)?\s*원?")
_WON = re.compile(r"(\d{1,3}(?:,\d{3})+)\s*원?|(\d{4,})\s*원")


def parse_price(text):
    """제목 등 자유 텍스트에서 가격 추정 (5만원, 3만5천, 50,000원, 50000원)."""
    if not text:
        return None
    t = str(text)
    m = _MAN.search(t)
    if m:
        v = float(m.group(1)) * 10000
        if m.group(2):
            v += int(m.group(2)) * 1000
        return int(v)
    m = _WON.search(t)
    if m:
        return int((m.group(1) or m.group(2)).replace(",", ""))
    return None


def to_int(v):
    """구조화된 가격 필드("30000.0", 30000, "30,000") → int. 실패 시 None."""
    if v is None or v == "":
        return None
    try:
        return int(float(str(v).replace(",", "").replace("원", "").strip()))
    except ValueError:
        return None


# ---------------------------------------------------------------- 비밀값 마스킹
_TOKEN_RE = re.compile(r"\d{6,}:[A-Za-z0-9_-]{25,}")
_BOT_URL_RE = re.compile(r"(api\.telegram\.org/bot)[^/\s'\"]+")
_secrets: set[str] = set()


def register_secret(s: str | None):
    if s and len(s) >= 8:
        _secrets.add(s)


def redact(text) -> str:
    s = str(text)
    for sec in _secrets:
        s = s.replace(sec, "[REDACTED]")
    s = _BOT_URL_RE.sub(r"\1[REDACTED]", s)
    return _TOKEN_RE.sub("[REDACTED]", s)


class RedactFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = redact(record.getMessage())
        record.args = ()
        if record.exc_info:  # 트레이스백 안의 URL/토큰도 문자열로 바꿔서 마스킹
            import traceback

            record.msg += "\n" + redact("".join(traceback.format_exception(*record.exc_info)))
            record.exc_info = None
            record.exc_text = None
        return True


def setup_logging():
    h = logging.StreamHandler()
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    h.addFilter(RedactFilter())
    root = logging.getLogger()
    root.handlers = [h]
    root.setLevel(logging.INFO)
    # httpx/httpcore 는 요청 URL(= 봇 토큰 포함)을 INFO 로 찍으므로 끈다.
    for name in ("httpx", "httpcore", "uvicorn.access"):
        logging.getLogger(name).setLevel(logging.WARNING)
