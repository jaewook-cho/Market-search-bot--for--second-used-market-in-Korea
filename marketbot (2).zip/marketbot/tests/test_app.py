"""오프라인 테스트: 파서(고정 HTML/JSON), 필터, 중복방지, 베이스라인, 토큰 마스킹, API."""
import asyncio
import json
import logging
import os
import sys
import tempfile

import pytest

os.environ["DATA_DIR"] = tempfile.mkdtemp()
os.environ["ADMIN_PASS"] = "pw"
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app.scrapers import bunjang, clien, daangn, dvdprime, joongna  # noqa: E402
from app.scrapers.base import Item  # noqa: E402
from app.util import RedactFilter, parse_price, register_secret, redact  # noqa: E402

TOKEN = "123456789:AAH_fakeTokenValue_abcdefghijklmnopqr"


def test_price():
    assert parse_price("아이폰 15만원 택포") == 150000
    assert parse_price("3만5천 판매") == 35000
    assert parse_price("가격 50,000원") == 50000
    assert parse_price("2024년식 모델") is None
    assert parse_price("1.5만") == 15000


def test_bunjang():
    items = bunjang.parse({"list": [
        {"pid": "1", "name": "A7M3", "price": "1500000", "update_time": 1760000000, "location": "서울",
         "product_image": "https://x/{cnt}_{res}.jpg"},
        {"pid": "2", "name": "광고", "price": "1", "ad": True}]})
    assert len(items) == 1 and items[0].price == 1500000
    assert items[0].url.endswith("/products/1") and "1_300" in items[0].thumb


def test_joongna():
    nd = {"props": {"pageProps": {"x": [{"seq": 55, "title": "맥북", "price": 900000, "url": "u"}]}}}
    html = f'<script id="__NEXT_DATA__" type="application/json">{json.dumps(nd)}</script>'
    it = joongna.parse(html)
    assert it[0].item_id == "55" and it[0].price == 900000


def test_daangn_json_and_html():
    ctx = {"state": {"loaderData": {"a": {"fleamarketArticles": [
        {"href": "https://www.daangn.com/kr/buy-sell/맥북-abc123xyz/", "title": "맥북", "price": "900000.0",
         "status": "Ongoing", "region": {"name": "역삼동"}, "createdAt": "2026-10-10T01:00:00Z"},
        {"href": "/kr/buy-sell/판매완료-zzz999aaa/", "title": "끝", "price": "1", "status": "Closed"}]}}}}
    html = f"<script>window.__remixContext = {json.dumps(ctx)};</script>"
    it = daangn.parse(html)
    assert len(it) == 1 and it[0].price == 900000 and it[0].location == "역삼동"
    h = '<a href="/kr/buy-sell/airpods-q1w2e3r4/"><img src="i.jpg"><span>에어팟</span><span>50,000원</span><span>역삼동</span></a>'
    it = daangn.parse(h)
    assert it[0].title == "에어팟" and it[0].price == 50000


def test_clien_dvdprime():
    h = ('<div class="list_item"><a class="list_subject" href="/service/board/sold/123?od=T31">'
         '<span class="subject_fixed" title="[삽니다] 모니터 12만원">x</span></a>'
         '<span class="timestamp">2026-10-10 12:00:00</span></div>')
    it = clien.parse(h)
    assert it[0].price == 120000 and it[0].posted_at
    h = '<a href="./board.php?bo_table=market&wr_id=777">블루레이 3만원</a><a href="./board.php?bo_table=market&wr_id=777#c_1">댓글</a>'
    it = dvdprime.parse(h)
    assert len(it) == 1 and it[0].price == 30000


def test_redaction():
    register_secret(TOKEN)
    rec = logging.LogRecord("x", logging.ERROR, "", 0,
                            f"HTTP error for https://api.telegram.org/bot{TOKEN}/sendMessage", (), None)
    RedactFilter().filter(rec)
    assert TOKEN not in rec.msg and "123456789" not in rec.msg
    assert TOKEN not in redact(f"fail {TOKEN}")


# ------------------------------------------------------------------ 엔진/API
@pytest.fixture()
def client(monkeypatch):
    from fastapi.testclient import TestClient
    from app import main, scrapers

    calls = {"n": 0}

    class Fake:
        key, label = "bunjang", "번개장터"

        async def search(self, c, q, region=""):
            calls["n"] += 1
            base = [Item("bunjang", "1", "소니 A7M3 바디", "http://u/1", 1500000),
                    Item("bunjang", "2", "소니 A7M3 부품용", "http://u/2", 300000),
                    Item("bunjang", "3", "소니 A7M3 풀박", "http://u/3", 3000000)]
            if calls["n"] >= 2:
                base.append(Item("bunjang", "4", "소니 A7M3 신규", "http://u/4", 1200000))
            return base

    monkeypatch.setitem(scrapers.REGISTRY, "bunjang", Fake())
    monkeypatch.setattr("app.engine.REGISTRY", scrapers.REGISTRY)
    with TestClient(main.app, headers={"Authorization": "Basic YWRtaW46cHc="}) as c:  # admin:pw
        c.sent = []

        async def fake_call(method, payload=None, token=None):
            if method == "sendMessage":
                c.sent.append(payload["text"])
            if method == "getMe":
                return True, {"username": "mybot"}
            return True, {"title": "chat"}
        main.engine.tg.call = fake_call
        yield c


def test_auth(client):
    from fastapi.testclient import TestClient
    from app import main
    assert TestClient(main.app).get("/api/meta").status_code == 401
    assert client.get("/healthz").status_code == 200


def test_flow(client):
    from app import main
    r = client.put("/api/settings", json={"tg_token": TOKEN, "tg_chat_id": "42",
                                          "sites_enabled": {"daangn": False, "joongna": False, "clien": False, "dvdprime": False}})
    assert r.json()["telegram_test"]["ok"]
    s = client.get("/api/settings").json()
    assert "tg_token" not in s and TOKEN not in json.dumps(s) and "•" in s["tg_token_masked"]
    # 마스킹된 값으로 다시 저장해도 토큰 유지
    client.put("/api/settings", json={"tg_token": s["tg_token_masked"]})
    assert main.db.get_settings()["tg_token"] == TOKEN

    client.post("/api/keywords", json={"query": "소니 a7m3", "min_price": 1000000, "max_price": 2000000, "exclude": "부품용"})
    run = lambda: asyncio.get_event_loop().run_until_complete(main.engine.run_cycle("manual"))  # noqa: E731
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(main.engine.run_cycle("manual"))
    assert client.get("/api/items").json()["total"] == 1     # 가격·제외어 필터 통과 1건
    assert client.sent == []                                   # 첫 실행은 베이스라인(알림 없음)
    loop.run_until_complete(main.engine.run_cycle("manual"))
    assert client.get("/api/items").json()["total"] == 2
    assert len(client.sent) == 1 and "신규" in client.sent[0]  # 새 글 1건만 알림
    loop.run_until_complete(main.engine.run_cycle("manual"))
    assert len(client.sent) == 1                               # 중복 알림 없음
    d = client.get("/api/dashboard").json()
    assert d["sites"][2]["status"]["ok"] == 1


def test_adhoc_sort(client):
    r = client.post("/api/search", json={"query": "소니 a7m3", "sites": ["bunjang"], "sort": "price"}).json()
    prices = [i["price"] for i in r["items"]]
    assert prices == sorted(prices)
